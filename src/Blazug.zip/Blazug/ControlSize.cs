﻿namespace Blazug;

public enum ControlSize
{
    Content, // take the size of the content.
    OneThird,
    Half,
    ThreeThird,
    Full
}

